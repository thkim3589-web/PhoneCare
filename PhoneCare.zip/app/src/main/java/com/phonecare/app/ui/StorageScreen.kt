package com.phonecare.app.ui

import android.Manifest
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.phonecare.app.data.FileCategory
import com.phonecare.app.data.FoundFile
import com.phonecare.app.data.StorageScanner
import com.phonecare.app.util.formatBytes
import com.phonecare.app.util.formatDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 파일 목록 정렬 기준 */
private enum class FileSort(val label: String) {
    SIZE("큰 순"),
    OLDEST("오래된 순"),
    NEWEST("최신 순"),
    NAME("이름 순");

    fun apply(files: List<FoundFile>): List<FoundFile> = when (this) {
        SIZE -> files.sortedByDescending { it.size }
        OLDEST -> files.sortedBy { it.modified }
        NEWEST -> files.sortedByDescending { it.modified }
        NAME -> files.sortedBy { it.name.lowercase() }
    }

    companion object {
        private const val PREFS = "storage"
        private const val KEY = "file_sort"

        fun load(context: Context): FileSort {
            val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            return entries.firstOrNull { it.name == saved } ?: SIZE
        }

        fun save(context: Context, sort: FileSort) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, sort.name).apply()
        }
    }
}

@Composable
fun StorageScreen(resumeTick: Int) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var sortOrder by remember { mutableStateOf(FileSort.load(context)) }

    var hasAccess by remember { mutableStateOf(StorageScanner.hasAccess(context)) }
    var scanning by remember { mutableStateOf(false) }
    var scannedCount by remember { mutableIntStateOf(0) }
    var results by remember { mutableStateOf<List<FoundFile>?>(null) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var expanded by remember { mutableStateOf(setOf<FileCategory>()) }
    var showConfirm by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    // 설정 화면에서 권한을 켜고 돌아오면 다시 확인
    LaunchedEffect(resumeTick) { hasAccess = StorageScanner.hasAccess(context) }

    val legacyPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { hasAccess = StorageScanner.hasAccess(context) }

    fun startScan() {
        scanning = true
        scannedCount = 0
        results = null
        selected = emptySet()
        scope.launch {
            val found = withContext(Dispatchers.IO) {
                StorageScanner.scan { n -> scannedCount = n }
            }
            results = found
            scanning = false
        }
    }

    val list = results.orEmpty()
    val selectedFiles = list.filter { it.path in selected }
    val selectedBytes = selectedFiles.sumOf { it.size }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                ScreenTitle("저장공간 정리", "필요 없는 파일을 찾아서 골라 지울 수 있어요")
            }

            if (!hasAccess) {
                item {
                    PermissionCard(
                        title = "파일 접근 권한이 필요해요",
                        description = "휴대폰 안의 큰 파일, 오래된 다운로드, 스크린샷을 찾으려면 " +
                            "'모든 파일 접근' 권한을 허용해 주세요. 파일은 내가 선택한 것만 삭제돼요.",
                        buttonText = "권한 허용하러 가기",
                    ) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            StorageScanner.openAllFilesSettings(context)
                        } else {
                            legacyPermissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.READ_EXTERNAL_STORAGE,
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                ),
                            )
                        }
                    }
                }
                return@LazyColumn
            }

            item {
                if (scanning) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("파일 검사 중… ($scannedCount 개 확인)")
                            LinearProgressIndicator(Modifier.fillMaxWidth())
                        }
                    }
                } else {
                    Button(onClick = { startScan() }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (results == null) "검사 시작" else "다시 검사")
                    }
                }
            }

            val current = results
            if (current != null && !scanning) {
                if (current.isEmpty()) {
                    item {
                        Text(
                            "정리할 파일을 찾지 못했어요. 잘 관리되고 있어요!",
                            Modifier.padding(vertical = 24.dp),
                            style = MaterialTheme.typography.bodyLarge,
                        )
                    }
                } else {
                    item {
                        Text(
                            "총 ${current.size}개 · ${formatBytes(current.sumOf { it.size })} 정리 가능",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    item {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            FileSort.entries.forEach { s ->
                                FilterChip(
                                    selected = sortOrder == s,
                                    onClick = {
                                        sortOrder = s
                                        FileSort.save(context, s)
                                    },
                                    label = { Text(s.label) },
                                )
                            }
                        }
                    }
                }

                FileCategory.entries.forEach { cat ->
                    val files = sortOrder.apply(current.filter { it.category == cat })
                    if (files.isEmpty()) return@forEach
                    val allSelected = files.all { it.path in selected }
                    val isOpen = cat in expanded

                    item(key = "header_${cat.name}") {
                        CategoryHeader(
                            category = cat,
                            count = files.size,
                            totalBytes = files.sumOf { it.size },
                            allSelected = allSelected,
                            isOpen = isOpen,
                            onToggleOpen = {
                                expanded = if (isOpen) expanded - cat else expanded + cat
                            },
                            onToggleAll = {
                                val paths = files.map { it.path }.toSet()
                                selected = if (allSelected) selected - paths else selected + paths
                            },
                        )
                    }
                    if (isOpen) {
                        items(files, key = { it.path }) { f ->
                            FileRow(
                                file = f,
                                checked = f.path in selected,
                                onToggle = {
                                    selected = if (f.path in selected) selected - f.path else selected + f.path
                                },
                            )
                        }
                    }
                }
            }
        }

        // 하단 삭제 바
        if (selectedFiles.isNotEmpty()) {
            Surface(tonalElevation = 4.dp, shadowElevation = 8.dp) {
                Button(
                    onClick = { showConfirm = true },
                    enabled = !deleting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) {
                    Text("선택한 ${selectedFiles.size}개 삭제 (${formatBytes(selectedBytes)})")
                }
            }
        }
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("파일 삭제") },
            text = {
                Text(
                    "${selectedFiles.size}개 파일(${formatBytes(selectedBytes)})을 삭제할까요?\n" +
                        "삭제한 파일은 휴지통으로 가지 않고 바로 지워져서 되돌릴 수 없어요.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    deleting = true
                    val toDelete = selectedFiles
                    scope.launch {
                        val (deletedPaths, freed) = withContext(Dispatchers.IO) {
                            StorageScanner.delete(context, toDelete)
                        }
                        results = results?.filterNot { it.path in deletedPaths }
                        selected = selected - deletedPaths
                        deleting = false
                        val failed = toDelete.size - deletedPaths.size
                        val msg = buildString {
                            append("${deletedPaths.size}개 삭제 · ${formatBytes(freed)} 확보")
                            if (failed > 0) append(" (${failed}개는 삭제 실패)")
                        }
                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    }
                }) { Text("삭제", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("취소") }
            },
        )
    }
}

@Composable
private fun CategoryHeader(
    category: FileCategory,
    count: Int,
    totalBytes: Long,
    allSelected: Boolean,
    isOpen: Boolean,
    onToggleOpen: () -> Unit,
    onToggleAll: () -> Unit,
) {
    Card(
        Modifier
            .fillMaxWidth()
            .clickable { onToggleOpen() },
    ) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(category.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${count}개 · ${formatBytes(totalBytes)}", color = MaterialTheme.colorScheme.primary)
                Text(category.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onToggleAll) { Text(if (allSelected) "선택 해제" else "전체 선택") }
            Icon(
                if (isOpen) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = if (isOpen) "접기" else "펼치기",
            )
        }
    }
}

@Composable
private fun FileRow(file: FoundFile, checked: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
        Box(Modifier.weight(1f)) {
            Column {
                Text(file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "${formatBytes(file.size)} · ${formatDate(file.modified)} · ${file.folder}",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
