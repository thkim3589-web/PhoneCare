package com.phonecare.app.ui

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.phonecare.app.data.BatteryInfo
import com.phonecare.app.data.DeviceInfo
import com.phonecare.app.data.MemoryInfoData
import com.phonecare.app.data.StorageInfoData
import com.phonecare.app.util.formatBytes
import kotlinx.coroutines.delay

private data class Recommendation(val text: String, val actionLabel: String? = null, val tab: Int = -1)

@Composable
fun HomeScreen(resumeTick: Int, onNavigate: (Int) -> Unit) {
    val context = LocalContext.current
    var battery by remember { mutableStateOf<BatteryInfo?>(null) }
    var memory by remember { mutableStateOf<MemoryInfoData?>(null) }
    var storage by remember { mutableStateOf<StorageInfoData?>(null) }

    // 화면에 있는 동안 5초마다 갱신
    LaunchedEffect(resumeTick) {
        while (true) {
            battery = DeviceInfo.battery(context)
            memory = DeviceInfo.memory(context)
            storage = DeviceInfo.storage()
            delay(5000)
        }
    }

    val score = DeviceInfo.score(battery, memory, storage)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenTitle("폰케어", "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}")

        ScoreCard(score)

        // 추천 조치
        val recs = buildRecommendations(battery, storage)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("추천 조치", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                recs.forEach { rec ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("• ${rec.text}", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        if (rec.actionLabel != null && rec.tab >= 0) {
                            TextButton(onClick = { onNavigate(rec.tab) }) { Text(rec.actionLabel) }
                        }
                    }
                }
            }
        }

        storage?.let { s ->
            StatCard(
                title = "저장공간",
                value = "${(s.usedRatio * 100).toInt()}% 사용",
                detail = "사용 ${formatBytes(s.used)} / 전체 ${formatBytes(s.total)} · 남은 공간 ${formatBytes(s.free)}",
                progress = s.usedRatio,
            )
        }

        memory?.let { m ->
            val usedRatio = if (m.total > 0) 1f - m.available.toFloat() / m.total else 0f
            StatCard(
                title = "메모리 (RAM)",
                value = "${(usedRatio * 100).toInt()}% 사용",
                detail = "사용 가능 ${formatBytes(m.available)} / 전체 ${formatBytes(m.total)}\n" +
                    "안드로이드는 남는 메모리를 캐시로 써서 빠르게 동작해요. 사용률이 높아도 정상이에요.",
                progress = usedRatio,
            )
        }

        battery?.let { b ->
            StatCard(
                title = "배터리",
                value = if (b.level >= 0) "${b.level}%" else "-",
                detail = "온도 ${"%.1f".format(b.temperatureC)}°C · 상태 ${b.health} · " +
                    (if (b.charging) "충전 중 (${b.plugged})" else b.plugged),
                progress = if (b.level >= 0) b.level / 100f else null,
            )
        }

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ScoreCard(score: Int) {
    val color = when {
        score >= 80 -> ScoreGood
        score >= 60 -> ScoreWarn
        else -> ScoreBad
    }
    val label = when {
        score >= 80 -> "상태 좋음"
        score >= 60 -> "점검 필요"
        else -> "관리 필요"
    }
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { score / 100f },
                    modifier = Modifier.size(110.dp),
                    color = color,
                    strokeWidth = 10.dp,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )
                Text("$score", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = color)
            }
            Spacer(Modifier.width(20.dp))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = color)
                Text(
                    "저장공간 · 메모리 · 배터리 온도와 상태를 종합한 점수예요",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, detail: String, progress: Float?) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
            if (progress != null) {
                val barColor: Color = when {
                    title == "배터리" -> MaterialTheme.colorScheme.primary
                    progress > 0.9f -> ScoreBad
                    progress > 0.8f -> ScoreWarn
                    else -> MaterialTheme.colorScheme.primary
                }
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    color = barColor,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )
            }
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun buildRecommendations(b: BatteryInfo?, s: StorageInfoData?): List<Recommendation> {
    val list = mutableListOf<Recommendation>()
    if (s != null) {
        val pct = (s.usedRatio * 100).toInt()
        when {
            s.usedRatio > 0.9f -> list.add(Recommendation("저장공간이 $pct% 찼어요. 정리가 급해요 — 속도 저하의 주원인이에요", "정리하기", 1))
            s.usedRatio > 0.8f -> list.add(Recommendation("저장공간이 $pct% 찼어요. 조금 정리하면 좋아요", "정리하기", 1))
        }
    }
    if (b != null) {
        if (b.temperatureC >= 40f) {
            list.add(Recommendation("배터리 온도가 높아요 (${"%.0f".format(b.temperatureC)}°C). 무거운 앱·충전을 잠시 멈추세요"))
        }
        if (!b.healthGood) {
            list.add(Recommendation("배터리 상태가 '${b.health}'로 표시돼요. 서비스센터 점검을 권장해요"))
        }
    }
    list.add(Recommendation("오랫동안 안 쓴 앱이 있는지 확인해 보세요", "앱 보기", 2))
    list.add(Recommendation("설정 최적화 체크리스트를 따라 해 보세요", "팁 보기", 3))
    return list
}
