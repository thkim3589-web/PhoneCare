package com.phonecare.app.data

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.phonecare.app.util.DAY_MS
import com.phonecare.app.util.daysAgo
import com.phonecare.app.util.openSettings

data class AppItem(
    val packageName: String,
    val label: String,
    val icon: ImageBitmap?,
    val lastUsed: Long,      // 0이면 조회 기간 동안 사용 기록 없음
    val installed: Long,
    val sizeBytes: Long,     // -1이면 알 수 없음
) {
    val neverUsed: Boolean get() = lastUsed <= 0L || lastUsed < installed
    val unusedDays: Long get() = if (neverUsed) daysAgo(installed) else daysAgo(lastUsed)
}

object AppUsage {

    const val LOOKBACK_DAYS = 180

    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName,
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName,
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccessSettings(context: Context) {
        context.openSettings(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    fun openUninstall(context: Context, packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName"))
        context.openSettings(intent)
    }

    fun openAppInfo(context: Context, packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        context.openSettings(intent)
    }

    fun isInstalled(context: Context, packageName: String): Boolean = try {
        @Suppress("DEPRECATION")
        context.packageManager.getApplicationInfo(packageName, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** 사용자가 설치한 앱 목록 + 마지막 사용일 + 용량 (백그라운드에서 호출) */
    fun loadApps(context: Context): List<AppItem> {
        val pm = context.packageManager
        val usm = context.getSystemService(UsageStatsManager::class.java)
        val ssm = context.getSystemService(StorageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val stats: Map<String, UsageStats> = try {
            usm.queryAndAggregateUsageStats(now - LOOKBACK_DAYS * DAY_MS, now)
        } catch (e: Exception) {
            emptyMap()
        }

        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcherIntent, 0)
        }
        val packages = resolved.map { it.activityInfo.packageName }
            .distinct()
            .filter { it != context.packageName }

        val iconSize = 96
        return packages.mapNotNull { pkg ->
            try {
                @Suppress("DEPRECATION")
                val ai = pm.getApplicationInfo(pkg, 0)
                val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                if (isSystem) return@mapNotNull null

                @Suppress("DEPRECATION")
                val pi = pm.getPackageInfo(pkg, 0)
                val size = try {
                    val s = ssm.queryStatsForPackage(ai.storageUuid, pkg, Process.myUserHandle())
                    s.appBytes + s.dataBytes
                } catch (e: Exception) {
                    -1L
                }
                val icon = try {
                    pm.getApplicationIcon(ai).toBitmap(iconSize, iconSize).asImageBitmap()
                } catch (e: Exception) {
                    null
                }
                AppItem(
                    packageName = pkg,
                    label = pm.getApplicationLabel(ai).toString(),
                    icon = icon,
                    lastUsed = stats[pkg]?.lastTimeUsed ?: 0L,
                    installed = pi.firstInstallTime,
                    sizeBytes = size,
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
